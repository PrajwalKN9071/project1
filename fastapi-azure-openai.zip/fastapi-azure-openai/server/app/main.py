from fastapi import FastAPI, APIRouter
from fastapi.middleware.cors import CORSMiddleware
from app.api.v1.endpoints import generate_text, facebook_auth

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:9090"],  # Adjust this to your client URL
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(generate_text.router, prefix="/api/v1")



app.include_router(facebook_auth.router, prefix="/api/v1/auth", tags=["Facebook Auth"])


@app.get("/test")
async def test():
    return {"message": "Test endpoint working"}


