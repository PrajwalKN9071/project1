from fastapi import APIRouter, HTTPException, Depends
from app.services.facebook_service import validate_facebook_token
from app.models.request import FacebookLoginRequest

router = APIRouter()

@router.post("/auth/facebook", summary="Handle Facebook Login")
async def facebook_login(request: FacebookLoginRequest):
    """
    Endpoint to validate Facebook access token and retrieve user profile data.
    """
    is_valid, user_data = await validate_facebook_token(request.access_token)
    if not is_valid:
        raise HTTPException(status_code=400, detail="Invalid Facebook access token")

    # Optionally, you can handle user registration or session creation here
    return {"success": True, "user": user_data}
