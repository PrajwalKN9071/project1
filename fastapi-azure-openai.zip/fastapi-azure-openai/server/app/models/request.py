from pydantic import BaseModel

class TextRequest(BaseModel):
    prompt: str

class FacebookLoginRequest(BaseModel):
    access_token: str

