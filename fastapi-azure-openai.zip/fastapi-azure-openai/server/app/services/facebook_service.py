import httpx

FACEBOOK_APP_ID = "582601060931574"
FACEBOOK_APP_SECRET = "EAAIR32FIVZCYBOZBc9qYDBz8RU4v5eLW6CZA9t7I79fQdey8wgDeGfM4CNLzETCrLvtOzwGnfpJ8QoLhLC3BcnUssWlccREp1DZBOC180etw518h3mP73ZARmxo49s1ZA5ni80LAN85i96JEHBFzGRuaZBDoBuGwS74KLvf0orFMpz5H74fqH6lLfNssQ3ii5Ua2zNYHgn03ZBkSMRSOLCM0s3edvZAiLq0PaZAHCD"

async def validate_facebook_token(access_token: str):
    """
    Validates the provided Facebook access token using Facebook's Graph API.
    """
    debug_token_url = f"https://graph.facebook.com/debug_token"
    debug_params = {
        "input_token": access_token,
        "access_token": f"{FACEBOOK_APP_ID}|{FACEBOOK_APP_SECRET}"
    }

    async with httpx.AsyncClient() as client:
        response = await client.get(debug_token_url, params=debug_params)
        if response.status_code == 200:
            data = response.json()
            is_valid = data.get("data", {}).get("is_valid", False)
            if is_valid:
                # Fetch user profile data
                return True, await fetch_facebook_user_data(access_token)
    return False, None

async def fetch_facebook_user_data(access_token: str):
    """
    Fetches the user's profile data from Facebook.
    """
    user_info_url = "https://graph.facebook.com/me"
    user_info_params = {
        "fields": "id,name,email",  # Customize fields as needed
        "access_token": access_token
    }

    async with httpx.AsyncClient() as client:
        response = await client.get(user_info_url, params=user_info_params)
        if response.status_code == 200:
            return response.json()
    return None
