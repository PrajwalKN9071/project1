from fastapi import FastAPI, HTTPException
import httpx

app = FastAPI()

FACEBOOK_APP_ID = "582601060931574"
FACEBOOK_APP_SECRET = "EAAIR32FIVZCYBOZBc9qYDBz8RU4v5eLW6CZA9t7I79fQdey8wgDeGfM4CNLzETCrLvtOzwGnfpJ8QoLhLC3BcnUssWlccREp1DZBOC180etw518h3mP73ZARmxo49s1ZA5ni80LAN85i96JEHBFzGRuaZBDoBuGwS74KLvf0orFMpz5H74fqH6lLfNssQ3ii5Ua2zNYHgn03ZBkSMRSOLCM0s3edvZAiLq0PaZAHCD"

@app.post("/auth/facebook")
async def facebook_login(access_token: str):
    url = f"https://graph.facebook.com/debug_token"
    params = {
        "input_token": access_token,
        "access_token": f"{FACEBOOK_APP_ID}|{FACEBOOK_APP_SECRET}"
    }

    async with httpx.AsyncClient() as client:
        response = await client.get(url, params=params)
        if response.status_code == 200:
            data = response.json()
            if data.get("data", {}).get("is_valid"):
                # Fetch user profile
                user_info_url = "https://graph.facebook.com/me"
                user_info_params = {
                    "fields": "id,name,email",
                    "access_token": access_token
                }
                user_response = await client.get(user_info_url, params=user_info_params)
                if user_response.status_code == 200:
                    user_data = user_response.json()
                    return {"success": True, "user": user_data}
        raise HTTPException(status_code=400, detail="Invalid Facebook token")
